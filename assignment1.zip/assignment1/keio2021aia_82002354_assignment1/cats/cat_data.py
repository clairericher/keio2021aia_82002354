from . import *

class Cat_Data:

    def __init__(self, data_file_path='', data_file_name='cat_data.pkl'):
        
        self.data = []
        self.train_mean = 0.0
        self.train_sd = 0.0
        
        #dont know how to do this part.

        with open(data_file_name, 'rb') as f:
            data = pkl.load(f)
        
        x = []
        y = []
        x_v = []
        
        for i in range(len(data['train']['cat'])):
            x.insert(i, data['train']['cat'][i])
            y.insert(i, 1)
        
        for i in range(len(data['train']['no_cat'])):
            x.insert(len(x), data['train']['no_cat'][i])
            y.insert(len(y), -1)
        
        x = self.standardize(x)
        
        for i in range(len(x)):
            x_v.insert(i, np.concatenate(np.concatenate(x[i])))
            self.data.insert(i, [x_v[i], y[i]])
        
        self.index = -1
    
        self.shuffle()

    def __iter__(self):
        
        return self

    def __next__(self):
        
        self.index += 1
        if self.index == (len(self.data)-1):
            raise StopIteration
        return self.data[self.index]
    
    def __len__(self):
        
        return len(self.data)
    
    def __getitem__(self, i):
        
        return self.data[i]

    def shuffle(self):
        
        random.shuffle(self.data)
    
    def standardize(self, rgb_images):
        
        mean = np.mean(rgb_images, axis=(0, 1, 2), keepdims=True)
        sd = np.std(rgb_images, axis=(0, 1, 2), keepdims=True)
        return (rgb_images - mean) / sd
