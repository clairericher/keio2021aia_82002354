from . import *

class Digits_Model:

    def __init__(self, dim_input=784, dim_hidden=[100], dim_out=10):

        self.layers = []
        
        self.dim_input = dim_input
        self.dim_hidden = dim_hidden
        self.dim_out = dim_out
        
        self.layers.append(Linear(self.dim_input, self.dim_hidden[0]))
        #for i in range(len(self.dim_hidden)):
        #    self.layers.append(Linear(self.dim_hidden[i], self.dim_hidden[i+1]))
        self.layers.append(Linear(self.dim_hidden[len(self.dim_hidden)-1], self.dim_out))
        self.layers.append(Tanh())
                
        self._predict = softmax
        
    def __str__(self):

        return "Simple Neural Network\n\
        \tInput dimension: %d\n\
        \tHidden dimensions: %d\n\
        \tOutput dimension: %d\n" % (self._dim_input, self._dim_hidden, self._dim_out)

    def __call__(self, x):
        
        prediction = None
        
        outputs = self.forward(x)
        prediction = np.argmax(softmax(outputs))
        
        # hint: use the forward and predict functions to obtain a probability distribution over digits, then pick the highest probability digit
        
        return prediction

    def load_model(self, file_path):
        
        with open(file_path, mode='rb') as f:
            loaded_model = pkl.load(f)

        self.__dict__.update(loaded_model.__dict__)

    def save_model(self):

        with open('results/digits_model.pkl','wb') as f:
            pkl.dump(self, f)
    
    def forward(self, inputs):
        
        outputs = None
        
        outputs = inputs
        
        for layer in self.layers:
            
            outputs = layer.forward(outputs)
        
        return outputs
        
        #a = self.layers[0].forward(inputs)
        #b = self.layers[1].forward(a)
        #outputs = ???
        
        #for layer in self.layers:
        #    new_inputs = []
        #    for neuron in range(len(layer.params['b'])):
        #        activation = layer.forward(inputs)
        #        new_inputs.append(activation)
        #    inputs = new_inputs
        #outputs = inputs            
        
        # hint: transform a batch of inputs (images) into a batch of outputs (final layer activations) using your model's layers in the order that they are supposed to be applied
            
        #return outputs

    def backward(self, grad):
        
        for layer in reversed(self.layers):
            
            grad = layer.backward(grad)
            
        return grad

    def params_and_grads(self):
        
        for layer in self.layers:
            
            for name, param in layer.params.items():
                
                grad = layer.grads[name]
                yield param, grad
